package entities

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	"sort"
	"time"
)

type Legal struct {
	FirstName string
	LastName  string
	Phone     string
	SSN       string
	Commute   string
	Ownership string
	Date      time.Time
}

type Legals []Legal

type CarLegal struct {
	CarID     string
	LegalList Legals
}

func (m Legals) Len() int {
	return len(m)
}
func (m Legals) Swap(i, j int) {
	m[i], m[j] = m[j], m[i]
}

func (m Legals) Less(i, j int) bool {
	return m[i].Date.Before(m[j].Date)
}

func (m *Legal) AddLegal(stub shim.ChaincodeStubInterface, args []string) error {
	carID := args[0]
	m.FirstName = args[1]
	m.LastName = args[2]
	m.Phone = args[3]
	m.SSN = args[4]
	m.Commute = args[5]
	m.Ownership = args[6]
	m.Date, _ = time.Parse("02-01-2000", args[7])

	var cm CarLegal
	cmJson, _ := stub.GetState("cm-" + carID)
	if cmJson == nil {
		cm.CarID = carID
	} else {
		err := json.Unmarshal(cmJson, &cm)
		if err != nil {
			return errors.New("AddLegal: Error in unmarshaling JSON")
		}
	}
	cm.LegalList = append(cm.LegalList, *m)
	sort.Sort(cm.LegalList)
	cmJsonIndent, _ := json.MarshalIndent(cm, "", "  ")
	err := stub.PutState("cm-"+carID, cmJsonIndent)
	if err != nil {
		return errors.New("AddLegal: Unable to PutState")
	}
	return nil
}

func (cm *CarLegal) GetLegalList(stub shim.ChaincodeStubInterface, carID string) ([]byte, error) {
	cmJsonIndent, err := stub.GetState("cm-" + carID)
	if err != nil {
		return nil, err
	}
	if cmJsonIndent == nil {
		cmJsonIndent = []byte("{\"Error\":\"No legal paper track available for carID " + carID + "\"}")
	}
	fmt.Println("GetCarJSON returned:", string(cmJsonIndent))
	return cmJsonIndent, nil
}

func (cm *CarLegal) LoadLegalSample(stub shim.ChaincodeStubInterface) string {
	var m Legal

	argslist := make([][]string, 3)
	argslist[0] = []string{"0001", "Thomas", "Larson", "+45 98 78 47", "141094-5458", "5", "Bought", "10-02-2012"}
	argslist[1] = []string{"0002", "Fyn", "Henriksen", "+45 55 78 44", "141094-5458", "10", "Bought", "10-02-2012"}
	argslist[2] = []string{"0003", "John", "Johnson", "+45 33 44 22", "141094-5458", "5", "Leased", "10-02-2012"}

	for _, args := range argslist {
		m.AddLegal(stub, args)
	}
	return "Load Legal samples: 3 inserted"
}
